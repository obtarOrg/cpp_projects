# Flight-Management-System
A flight management system written in C++. It is a simple program with following features:

FLIGHT BOOKING

MANAGING BOOKING

CHOOSE YOUR TYPE (LOCAL/INTERNATIONAL)

and Some extra features...
